

def main():
    num1 = int(input('informe o primeiro numero: '))
    num2 = int(input('informe o segundo numero: '))

    print('qual é sua escolha de calculo?')
    opcao = int(input('1 - adicao\n2 - subtracao\n3- multiplicacao\n4 - divisao'))

    if opcao == 1:
        resultado = num1 + num2
    elif opcao == 2:
        resultado = num1 - num2
    elif opcao == 3:
        resultado = num1 * num2
    elif opcao == 4:
        resultado = num1 / num2
    else:
        print('opção inválida')
        exit()

    print('Resultado = ',resultado)

    if resultado % 2 == 0:
        print('numero par')
    else:
        print('numero impar')

    if resultado >= 0:
        print('numero positivo')
    else:
        print('numero negativo')

    if type(resultado) == "<class 'int'>":
        print('Numero inteiro')
    else:
        print('numero flutuante')


if __name__ == '__main__':
    main()
