numero = float(input('Informe um número: '))
resultado = numero % 2
if resultado == 0:
        print(f'o número {numero} é PAR')
else:
        print(f'o número {numero} é IMPAR')