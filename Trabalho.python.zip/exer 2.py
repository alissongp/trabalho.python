num = float(input('informe um numero: '))
if num == round(num):
    print('inteiro')
else:
    print('decimal')