macakg = float(input("Insira a quantidade de maças em KG: "))
morangokg  = float(input("Insira a quantidade de morangos em KG: "))

if macakg < 5:
	valorMaca = macakg * 2.5
else:
	valorMaca = macakg * 2

if morangokg < 5:
	valorMorango = morangokg * 8.9
else:
	valorMorango = morangokg * 7.5

if ((valorMaca + valorMorango) < 25) :
	total = valorMaca + valorMorango
	print("O valor da sua compra é de: ", total)
else:
	total = valorMaca + valorMorango - ((valorMaca + valorMorango) * 0.1)
	print("O valor da sua compra é de: ", total)